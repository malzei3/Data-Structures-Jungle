
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>

/**
  This file contains some toy code which illustrate example
    usage of the standard template library unordered_map class 
    among other things.  Some other C++ concepts illustrated
    include:

        the std::sort function
        command-line arguments
        opening and reading from files
        the "foreach" construct to iterate over elements
           in an STL "container"

  The program itself reads a text file and builds a
  "frequency-count" data structure using an unordered_map.

  For each ditsinct string in the input file, the map 
  keeps track of the number of time that string appears
  in the file.
**/


/*
*  this function rearranged the characters in a string
*    so that they are sorted (according to their ASCII
*    value).
*
*  Resource:  https://en.cppreference.com/w/cpp/algorithm/sort
*
*  Note:  this function is not actually used the the program
*    in this file.  But you might find it useful... :)
*/
void ssort(std::string &s) {

  /*
     strings are "iterable" objects and so have the begin()
     and end() functions.  These functions (in a pretty
     abstract way) return "iterators" which specify the
     "beginning" and "end" of the associated object).

     Thus, this call is asking the sort function to sort
     the entire string s.
  */
  std::sort(s.begin(), s.end());
}


/*
*   usage:   ./freq <filename>
*
*   example:  ./freq words.txt
*
*/
int main(int argc, char *argv[]){
  /*
     the variable jumble is an unordered_map
        from strings to integers.
  */
  std::unordered_map<std::string, std::vector<std::string>> jumble;
  std::ifstream file;
  std::string word;
  std::string maxKey;
  std::string ogWord; 
  int currentMax = 0;       // holds the current biggest class size
  int count = 0;            // word count
  

  if(argc != 2) {
    std::cout << "usage:  ./freq <filename>\n";
    std::cout << "goodbye\n";
    return 1;
  }

  /*
  *  argv[1] is a C-string which is the filename specified
  *    by the user.  Let's try to open it.
  */

  file.open(argv[1], std::ios::in);

  if(!file.is_open()){
    std::cout << "Error: could not open file '" <<
                     argv[1] << "'\n";
    std::cout << "goodbye\n";
    return 1;
  }
  //jumble[word] = std::vector<std::string>();

  std::cout << "reading input file...\n";
	
  while(file >> word) { 
    // file >> word; 
	
    ogWord = word;
    ssort(word);
	count++;

    if(jumble.count(word) == 0) {                    // first vector element
        jumble[word] = std::vector<std::string>();
        jumble[word].push_back(ogWord);
    }
    else {
        jumble[word].push_back(ogWord);              
    }

    if (jumble[word].size() > currentMax) {           // update variables that store the biggest values, finds largest class
        maxKey = word;
        currentMax = jumble[word].size();
    }

  }

  std::cout <<"start entering jumbled words (ctrl-d to terminate)\n\n";
  std::cout << "> ";

  while(std::cin >> word) {             // print if anagrams were found, otherwise try again
    int i = 0;
    ssort(word);

    if(jumble.count(word)==0) {
        std::cout << "no anagrams found...try again\n";
    }
    else {
        std::cout << "English Anagrams Found:\n";
        while (i < jumble[word].size()) {
            std::cout<<"\t"<<jumble[word][i]<<std::endl;
            i++;
        }
    }
    std::cout << "> ";
  }
  // user has quit.  Let's dump the map contents

  printf("> REPORT:\n\n");
  std::cout << "\tnum_words\t\t: " << count <<std::endl;
  std::cout << "\tnum_classes\t\t: " << jumble.size() <<std::endl;
  std::cout << "\tsize-of-largest-class\t: " << currentMax <<std::endl;
  std::cout << "\tlargest-class key\t: '" << maxKey<< "'" <<std::endl;
  std::cout << "\tmembers of largest class:\n\n";

  for(int i = 0; i < jumble[maxKey].size(); i++) {
    std::cout<< "\t'" <<jumble[maxKey][i]<<"'"<<std::endl;
  }

  return 0;
}